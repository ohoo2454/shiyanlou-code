#coding:utf-8
from .constants import *

def exit(args):
    return SHELL_STATUS_STOP