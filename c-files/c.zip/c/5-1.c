#include<stdio.h>                
int main()
{
  int a=22;
  int b=3;
  printf("%d\n",a/b);
   
  return 0;
}