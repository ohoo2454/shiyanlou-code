#include<stdio.h>
#include<math.h>               
int main()
{
    int a=12,b=-3456;
    long int c=123456;
    printf("%5d\n",a);
    printf("%d\n",b);
    printf("%ld\n",c);
    printf("%d\n",c);
    
    return 0;
}