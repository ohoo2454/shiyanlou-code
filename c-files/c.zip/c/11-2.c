#include<stdio.h>
int main(){
    char *string="I love Shiyanlou!";
    printf("%s\n",string);
    
    return 0;
}