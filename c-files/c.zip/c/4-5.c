#include<stdio.h>                
int main()
{
  char a,x;
  int b;
  a='c';
  b=1;
  x=a+b;
  printf("%c\n",x);
  printf("%d\n",x);
   
  return 0;
}