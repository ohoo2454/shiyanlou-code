#include<stdio.h>
int main()
{
    char c1,c2;
    printf("Please enter a capital letter:");
    scanf("%c",&c1);
    c2=c1+32;
    printf("\n%c",c2);
    return 0;
}