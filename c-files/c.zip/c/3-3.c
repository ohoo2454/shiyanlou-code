#include<stdio.h>                
int main()
{
   printf("%d\n",sizeof(int));
   printf("%d\n",sizeof(short));
   printf("%d\n",sizeof(long));
   
   return 0;
}