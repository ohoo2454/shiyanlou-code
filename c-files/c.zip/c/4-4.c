#include<stdio.h>                
int main()
{
  char a,b;
  a='c';
  b=121;
  printf("%c,%c\n",a,b);
  printf("%d,%d\n",a,b);
   
  return 0;
}