#include<stdio.h>
int main(){
    char string[]="I love Shiyanlou!";
    printf("%s\n",string);
    printf("%c\n",string[9]);
    
    return 0;
}