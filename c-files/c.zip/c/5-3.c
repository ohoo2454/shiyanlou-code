#include<stdio.h>                
int main()
{
  int i=3;
  float f=4.3;
  double d=7.5;
  double sum;
  sum=10+'a'+i*f-d/3;
  
  return 0;
}