#include<stdio.h>
#include<math.h>              
int main()
{
    char a,b,c;
    a='O';b='K';c='\n';
    putchar(a);
	putchar(b);
	putchar(c);
    
    return 0;
}
