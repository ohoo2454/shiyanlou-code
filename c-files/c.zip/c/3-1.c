#include<stdio.h>                
int main()
{
   int a,b,c;
   printf(" Please enter a value:");
   scanf("%d",&a);
   printf("\n");
   printf("Please enter b value");
   scanf("%d",&b);
   c=a+b;
   printf("\n%d",c);
   return 0;
}